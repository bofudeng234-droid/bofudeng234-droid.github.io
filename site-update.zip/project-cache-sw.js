const CACHE='bofu-projects-v2-2db24589f69f1e3a';
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',event=>event.waitUntil((async()=>{
  try{for(const name of await caches.keys())if(name.startsWith('bofu-projects-')&&name!==CACHE)await caches.delete(name)}catch(error){console.warn('Project cache cleanup unavailable.',error.message)}
  await self.clients.claim();
})()));
async function rangeResponse(response,range){
  const buffer=await response.arrayBuffer(),size=buffer.byteLength;
  const match=/^bytes=(\d*)-(\d*)$/.exec(range);
  if(!match||(!match[1]&&!match[2]))return new Response(null,{status:416,headers:{'Content-Range':`bytes */${size}`}});
  const start=match[1]?Number(match[1]):Math.max(0,size-Number(match[2]));
  const end=match[1]?(match[2]?Math.min(Number(match[2]),size-1):size-1):size-1;
  if(start>=size||start>end)return new Response(null,{status:416,headers:{'Content-Range':`bytes */${size}`}});
  const headers=new Headers(response.headers);
  headers.set('Content-Range',`bytes ${start}-${end}/${size}`);
  headers.set('Content-Length',String(end-start+1));
  headers.set('Accept-Ranges','bytes');
  return new Response(buffer.slice(start,end+1),{status:206,statusText:'Partial Content',headers});
}
self.addEventListener('fetch',event=>{
  const url=new URL(event.request.url);
  if(event.request.method!=='GET'||url.origin!==self.location.origin||!(url.pathname.startsWith('/demos/')||url.pathname.startsWith('/media/about/')||url.pathname.startsWith('/fonts/')||url.pathname.startsWith('/audio/music/'))||url.searchParams.has('warm')||event.request.headers.has('X-Bofu-Preload'))return;
  event.respondWith((async()=>{
    try{
      const response=await (await caches.open(CACHE)).match(url.origin+url.pathname);
      if(response){const range=event.request.headers.get('Range');return range?await rangeResponse(response,range):response;}
    }catch(error){console.warn('Project cache read failed; requesting the original file.',error.message)}
    return fetch(event.request);
  })());
});
